// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyAOqUd98LMEvlevJGZmTwZCjFylTgKLWeQ",
    authDomain: "urbanroots-cf6a2.firebaseapp.com",
    projectId: "urbanroots-cf6a2",
    storageBucket: "urbanroots-cf6a2.appspot.com",
    messagingSenderId: "711889604985",
    appId: "1:711889604985:web:4c63225796c2fb03ccdfa8"  
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
