import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-share-my-garden',
  templateUrl: './share-my-garden.component.html',
  styleUrls: ['./share-my-garden.component.css']
})
export class ShareMyGardenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
