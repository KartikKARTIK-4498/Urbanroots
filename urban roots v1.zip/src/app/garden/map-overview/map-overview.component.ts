import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-map-overview',
  templateUrl: './map-overview.component.html',
  styleUrls: ['./map-overview.component.css']
})
export class MapOverviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
