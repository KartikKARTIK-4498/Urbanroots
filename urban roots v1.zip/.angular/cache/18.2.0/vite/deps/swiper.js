import {
  Swiper
} from "./chunk-2NESOTSB.js";
import "./chunk-TRU5CPND.js";
import "./chunk-KTESVR3Q.js";
export {
  Swiper,
  Swiper as default
};
//# sourceMappingURL=swiper.js.map
