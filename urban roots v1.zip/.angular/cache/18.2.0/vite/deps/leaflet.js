import {
  require_leaflet_src
} from "./chunk-N6VQQCET.js";
import "./chunk-KTESVR3Q.js";
export default require_leaflet_src();
//# sourceMappingURL=leaflet.js.map
