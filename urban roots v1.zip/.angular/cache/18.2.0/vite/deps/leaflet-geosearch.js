import {
  require_leaflet_src
} from "./chunk-N6VQQCET.js";
import {
  __toESM
} from "./chunk-KTESVR3Q.js";

// node_modules/leaflet-geosearch/dist/geosearch.module.js
var e = __toESM(require_leaflet_src());
function t() {
  return t = Object.assign ? Object.assign.bind() : function(e3) {
    for (var t2 = 1; t2 < arguments.length; t2++) {
      var r2 = arguments[t2];
      for (var n2 in r2) Object.prototype.hasOwnProperty.call(r2, n2) && (e3[n2] = r2[n2]);
    }
    return e3;
  }, t.apply(this, arguments);
}
function r(e3, t2) {
  e3.prototype = Object.create(t2.prototype), e3.prototype.constructor = e3, n(e3, t2);
}
function n(e3, t2) {
  return n = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e4, t3) {
    return e4.__proto__ = t3, e4;
  }, n(e3, t2);
}
function o() {
  if ("undefined" == typeof Reflect || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if ("function" == typeof Proxy) return true;
  try {
    return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
    })), true;
  } catch (e3) {
    return false;
  }
}
function i(e3, t2, r2) {
  return i = o() ? Reflect.construct.bind() : function(e4, t3, r3) {
    var o2 = [null];
    o2.push.apply(o2, t3);
    var i2 = new (Function.bind.apply(e4, o2))();
    return r3 && n(i2, r3.prototype), i2;
  }, i.apply(null, arguments);
}
function s(e3, t2, r2, n2) {
  void 0 === t2 && (t2 = ""), void 0 === n2 && (n2 = {});
  var o2 = document.createElement(e3);
  return t2 && (o2.className = t2), Object.keys(n2).forEach(function(e4) {
    if ("function" == typeof n2[e4]) {
      var t3 = 0 === e4.indexOf("on") ? e4.substr(2).toLowerCase() : e4;
      o2.addEventListener(t3, n2[e4]);
    } else "html" === e4 ? o2.innerHTML = n2[e4] : "text" === e4 ? o2.innerText = n2[e4] : o2.setAttribute(e4, n2[e4]);
  }), r2 && r2.appendChild(o2), o2;
}
function a(e3) {
  e3.preventDefault(), e3.stopPropagation();
}
var l = function() {
  return [].slice.call(arguments).filter(Boolean).join(" ").trim();
};
function c(e3, t2) {
  e3 && e3.classList && (Array.isArray(t2) ? t2 : [t2]).forEach(function(t3) {
    e3.classList.contains(t3) || e3.classList.add(t3);
  });
}
function u(e3, t2) {
  e3 && e3.classList && (Array.isArray(t2) ? t2 : [t2]).forEach(function(t3) {
    e3.classList.contains(t3) && e3.classList.remove(t3);
  });
}
var h;
var p = 13;
var d = 40;
var f = 38;
var m = [p, 27, d, f, 37, 39];
var v = function() {
  function e3(e4) {
    var t3 = this, r2 = e4.handleSubmit, n2 = e4.searchLabel, o2 = e4.classNames, i2 = void 0 === o2 ? {} : o2;
    this.container = void 0, this.form = void 0, this.input = void 0, this.handleSubmit = void 0, this.hasError = false, this.container = s("div", l("geosearch", i2.container)), this.form = s("form", ["", i2.form].join(" "), this.container, {
      autocomplete: "none",
      onClick: a,
      onDblClick: a,
      touchStart: a,
      touchEnd: a
    }), this.input = s("input", ["glass", i2.input].join(" "), this.form, {
      type: "text",
      placeholder: n2 || "search",
      onInput: this.onInput,
      onKeyUp: function(e5) {
        return t3.onKeyUp(e5);
      },
      onKeyPress: function(e5) {
        return t3.onKeyPress(e5);
      },
      onFocus: this.onFocus,
      onBlur: this.onBlur,
      onClick: function() {
        t3.input.focus(), t3.input.dispatchEvent(new Event("focus"));
      }
    }), this.handleSubmit = r2;
  }
  var t2 = e3.prototype;
  return t2.onFocus = function() {
    c(this.form, "active");
  }, t2.onBlur = function() {
    u(this.form, "active");
  }, t2.onSubmit = function(e4) {
    try {
      var t3 = this;
      return a(e4), u(r2 = t3.container, "error"), c(r2, "pending"), Promise.resolve(t3.handleSubmit({
        query: t3.input.value
      })).then(function() {
        u(t3.container, "pending");
      });
    } catch (e5) {
      return Promise.reject(e5);
    }
    var r2;
  }, t2.onInput = function() {
    this.hasError && (u(this.container, "error"), this.hasError = false);
  }, t2.onKeyUp = function(e4) {
    27 === e4.keyCode && (u(this.container, ["pending", "active"]), this.input.value = "", document.body.focus(), document.body.blur());
  }, t2.onKeyPress = function(e4) {
    e4.keyCode === p && this.onSubmit(e4);
  }, t2.setQuery = function(e4) {
    this.input.value = e4;
  }, e3;
}();
var g = function() {
  function e3(e4) {
    var t3 = this, r2 = e4.handleClick, n2 = e4.classNames, o2 = void 0 === n2 ? {} : n2, i2 = e4.notFoundMessage;
    this.handleClick = void 0, this.selected = -1, this.results = [], this.container = void 0, this.resultItem = void 0, this.notFoundMessage = void 0, this.onClick = function(e5) {
      if ("function" == typeof t3.handleClick) {
        var r3 = e5.target;
        if (r3 && t3.container.contains(r3) && r3.hasAttribute("data-key")) {
          var n3 = Number(r3.getAttribute("data-key"));
          t3.handleClick({
            result: t3.results[n3]
          });
        }
      }
    }, this.handleClick = r2, this.notFoundMessage = i2 ? s("div", l(o2.notfound), void 0, {
      html: i2
    }) : void 0, this.container = s("div", l("results", o2.resultlist)), this.container.addEventListener("click", this.onClick, true), this.resultItem = s("div", l(o2.item));
  }
  var t2 = e3.prototype;
  return t2.render = function(e4, t3) {
    var r2 = this;
    void 0 === e4 && (e4 = []), this.clear(), e4.forEach(function(e5, n2) {
      var o2 = r2.resultItem.cloneNode(true);
      o2.setAttribute("data-key", "" + n2), o2.innerHTML = t3({
        result: e5
      }), r2.container.appendChild(o2);
    }), e4.length > 0 ? (c(this.container.parentElement, "open"), c(this.container, "active")) : this.notFoundMessage && (this.container.appendChild(this.notFoundMessage), c(this.container.parentElement, "open")), this.results = e4;
  }, t2.select = function(e4) {
    return Array.from(this.container.children).forEach(function(t3, r2) {
      return r2 === e4 ? c(t3, "active") : u(t3, "active");
    }), this.selected = e4, this.results[e4];
  }, t2.count = function() {
    return this.results ? this.results.length : 0;
  }, t2.clear = function() {
    for (this.selected = -1; this.container.lastChild; ) this.container.removeChild(this.container.lastChild);
    u(this.container.parentElement, "open"), u(this.container, "active");
  }, e3;
}();
var y = {
  position: "topleft",
  style: "button",
  showMarker: true,
  showPopup: false,
  popupFormat: function(e3) {
    return "" + e3.result.label;
  },
  resultFormat: function(e3) {
    return "" + e3.result.label;
  },
  marker: {
    icon: e && e.Icon ? new e.Icon.Default() : void 0,
    draggable: false
  },
  maxMarkers: 1,
  maxSuggestions: 5,
  retainZoomLevel: false,
  animateZoom: true,
  searchLabel: "Enter address",
  clearSearchLabel: "Clear search",
  notFoundMessage: "",
  messageHideDelay: 3e3,
  zoomLevel: 18,
  classNames: {
    container: "leaflet-bar leaflet-control leaflet-control-geosearch",
    button: "leaflet-bar-part leaflet-bar-part-single",
    resetButton: "reset",
    msgbox: "leaflet-bar message",
    form: "",
    input: "",
    resultlist: "",
    item: "",
    notfound: "leaflet-bar-notfound"
  },
  autoComplete: true,
  autoCompleteDelay: 250,
  autoClose: false,
  keepResult: false,
  updateMap: true
};
var b = "Leaflet must be loaded before instantiating the GeoSearch control";
var E = {
  options: t({}, y),
  classNames: t({}, y.classNames),
  initialize: function(r2) {
    var n2, o2, i2, a2, l2 = this;
    if (!e) throw new Error(b);
    if (!r2.provider) throw new Error("Provider is missing from options");
    this.options = t({}, y, r2), this.classNames = t({}, this.classNames, r2.classNames), this.markers = new e.FeatureGroup(), this.classNames.container += " leaflet-geosearch-" + this.options.style, this.searchElement = new v({
      searchLabel: this.options.searchLabel,
      classNames: {
        container: this.classNames.container,
        form: this.classNames.form,
        input: this.classNames.input
      },
      handleSubmit: function(e3) {
        return l2.onSubmit(e3);
      }
    }), this.button = s("a", this.classNames.button, this.searchElement.container, {
      title: this.options.searchLabel,
      href: "#",
      onClick: function(e3) {
        return l2.onClick(e3);
      }
    }), e.DomEvent.disableClickPropagation(this.button), this.resetButton = s("button", this.classNames.resetButton, this.searchElement.form, {
      text: "×",
      "aria-label": this.options.clearSearchLabel,
      onClick: function() {
        "" === l2.searchElement.input.value ? l2.close() : l2.clearResults(null, true);
      }
    }), e.DomEvent.disableClickPropagation(this.resetButton), this.options.autoComplete && (this.resultList = new g({
      handleClick: function(e3) {
        var t2 = e3.result;
        l2.searchElement.input.value = t2.label, l2.onSubmit({
          query: t2.label,
          data: t2
        });
      },
      classNames: {
        resultlist: this.classNames.resultlist,
        item: this.classNames.item,
        notfound: this.classNames.notfound
      },
      notFoundMessage: this.options.notFoundMessage
    }), this.searchElement.form.appendChild(this.resultList.container), this.searchElement.input.addEventListener("keyup", (n2 = function(e3) {
      return l2.autoSearch(e3);
    }, void 0 === (o2 = this.options.autoCompleteDelay) && (o2 = 250), void 0 === i2 && (i2 = false), function() {
      var e3 = [].slice.call(arguments);
      a2 && clearTimeout(a2), a2 = setTimeout(function() {
        a2 = null, i2 || n2.apply(void 0, e3);
      }, o2), i2 && !a2 && n2.apply(void 0, e3);
    }), true), this.searchElement.input.addEventListener("keydown", function(e3) {
      return l2.selectResult(e3);
    }, true), this.searchElement.input.addEventListener("keydown", function(e3) {
      return l2.clearResults(e3, true);
    }, true)), this.searchElement.form.addEventListener("click", function(e3) {
      e3.preventDefault();
    }, false);
  },
  onAdd: function(t2) {
    var r2 = this.options, n2 = r2.showMarker, o2 = r2.style;
    if (this.map = t2, n2 && this.markers.addTo(t2), "bar" === o2) {
      var i2 = t2.getContainer().querySelector(".leaflet-control-container");
      this.container = s("div", "leaflet-control-geosearch leaflet-geosearch-bar"), this.container.appendChild(this.searchElement.form), i2.appendChild(this.container);
    }
    return e.DomEvent.disableClickPropagation(this.searchElement.form), this.searchElement.container;
  },
  onRemove: function() {
    var e3;
    return null == (e3 = this.container) || e3.remove(), this;
  },
  open: function() {
    var e3 = this.searchElement, t2 = e3.input;
    c(e3.container, "active"), t2.focus();
  },
  close: function() {
    u(this.searchElement.container, "active"), this.clearResults();
  },
  onClick: function(e3) {
    e3.preventDefault(), e3.stopPropagation(), this.searchElement.container.classList.contains("active") ? this.close() : this.open();
  },
  selectResult: function(e3) {
    if (-1 !== [p, d, f].indexOf(e3.keyCode)) if (e3.preventDefault(), e3.keyCode !== p) {
      var t2 = this.resultList.count() - 1;
      if (!(t2 < 0)) {
        var r2 = this.resultList.selected, n2 = e3.keyCode === d ? r2 + 1 : r2 - 1, o2 = this.resultList.select(n2 < 0 ? t2 : n2 > t2 ? 0 : n2);
        this.searchElement.input.value = o2.label;
      }
    } else {
      var i2 = this.resultList.select(this.resultList.selected);
      this.onSubmit({
        query: this.searchElement.input.value,
        data: i2
      });
    }
  },
  clearResults: function(e3, t2) {
    if (void 0 === t2 && (t2 = false), !e3 || 27 === e3.keyCode) {
      var r2 = this.options, n2 = r2.autoComplete;
      !t2 && r2.keepResult || (this.searchElement.input.value = "", this.markers.clearLayers()), n2 && this.resultList.clear();
    }
  },
  autoSearch: function(e3) {
    try {
      var t2 = this;
      if (m.indexOf(e3.keyCode) > -1) return Promise.resolve();
      var r2 = e3.target.value, n2 = t2.options.provider, o2 = function() {
        if (r2.length) return Promise.resolve(n2.search({
          query: r2
        })).then(function(e4) {
          e4 = e4.slice(0, t2.options.maxSuggestions), t2.resultList.render(e4, t2.options.resultFormat);
        });
        t2.resultList.clear();
      }();
      return Promise.resolve(o2 && o2.then ? o2.then(function() {
      }) : void 0);
    } catch (e4) {
      return Promise.reject(e4);
    }
  },
  onSubmit: function(e3) {
    try {
      var t2 = this;
      return t2.resultList.clear(), Promise.resolve(t2.options.provider.search(e3)).then(function(r2) {
        r2 && r2.length > 0 && t2.showResult(r2[0], e3);
      });
    } catch (e4) {
      return Promise.reject(e4);
    }
  },
  showResult: function(e3, t2) {
    var r2 = this.options, n2 = r2.autoClose, o2 = r2.updateMap, i2 = this.markers.getLayers();
    i2.length >= this.options.maxMarkers && this.markers.removeLayer(i2[0]);
    var s2 = this.addMarker(e3, t2);
    o2 && this.centerMap(e3), this.map.fireEvent("geosearch/showlocation", {
      location: e3,
      marker: s2
    }), n2 && this.closeResults();
  },
  closeResults: function() {
    var e3 = this.searchElement.container;
    e3.classList.contains("active") && u(e3, "active"), this.clearResults();
  },
  addMarker: function(t2, r2) {
    var n2 = this, o2 = this.options, i2 = o2.marker, s2 = o2.showPopup, a2 = o2.popupFormat, l2 = new e.Marker([t2.y, t2.x], i2), c2 = t2.label;
    return "function" == typeof a2 && (c2 = a2({
      query: r2,
      result: t2
    })), l2.bindPopup(c2), this.markers.addLayer(l2), s2 && l2.openPopup(), i2.draggable && l2.on("dragend", function(e3) {
      n2.map.fireEvent("geosearch/marker/dragend", {
        location: l2.getLatLng(),
        event: e3
      });
    }), l2;
  },
  centerMap: function(t2) {
    var r2 = this.options, n2 = r2.retainZoomLevel, o2 = r2.animateZoom, i2 = t2.bounds ? new e.LatLngBounds(t2.bounds) : new e.LatLng(t2.y, t2.x).toBounds(10), s2 = i2.isValid() ? i2 : this.markers.getBounds();
    !n2 && i2.isValid() && !t2.bounds || n2 || !i2.isValid() ? this.map.setView(s2.getCenter(), this.getZoom(), {
      animate: o2
    }) : this.map.fitBounds(s2, {
      animate: o2
    });
  },
  getZoom: function() {
    var e3 = this.options, t2 = e3.zoomLevel;
    return e3.retainZoomLevel ? this.map.getZoom() : t2;
  }
};
function w() {
  if (!e) throw new Error(b);
  var t2 = e.Control.extend(E);
  return i(t2, [].slice.call(arguments));
}
!function(e3) {
  e3[e3.SEARCH = 0] = "SEARCH", e3[e3.REVERSE = 1] = "REVERSE";
}(h || (h = {}));
var x = function() {
  function e3(e4) {
    void 0 === e4 && (e4 = {}), this.options = void 0, this.options = e4;
  }
  var r2 = e3.prototype;
  return r2.getParamString = function(e4) {
    void 0 === e4 && (e4 = {});
    var r3 = t({}, this.options.params, e4);
    return Object.keys(r3).map(function(e5) {
      return encodeURIComponent(e5) + "=" + encodeURIComponent(r3[e5]);
    }).join("&");
  }, r2.getUrl = function(e4, t2) {
    return e4 + "?" + this.getParamString(t2);
  }, r2.search = function(e4) {
    try {
      var t2 = this, r3 = t2.endpoint({
        query: e4.query,
        type: h.SEARCH
      });
      return Promise.resolve(fetch(r3)).then(function(e5) {
        return Promise.resolve(e5.json()).then(function(e6) {
          return t2.parse({
            data: e6
          });
        });
      });
    } catch (e5) {
      return Promise.reject(e5);
    }
  }, e3;
}();
var k = function(e3) {
  function t2() {
    for (var t3, r2 = arguments.length, n3 = new Array(r2), o2 = 0; o2 < r2; o2++) n3[o2] = arguments[o2];
    return (t3 = e3.call.apply(e3, [this].concat(n3)) || this).searchUrl = "https://dev.virtualearth.net/REST/v1/Locations", t3;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = "string" == typeof t3 ? {
      q: t3
    } : t3;
    return r2.jsonp = e4.jsonp, this.getUrl(this.searchUrl, r2);
  }, n2.parse = function(e4) {
    return 0 === e4.data.resourceSets.length ? [] : e4.data.resourceSets[0].resources.map(function(e5) {
      return {
        x: e5.point.coordinates[1],
        y: e5.point.coordinates[0],
        label: e5.address.formattedAddress,
        bounds: [[e5.bbox[0], e5.bbox[1]], [e5.bbox[2], e5.bbox[3]]],
        raw: e5
      };
    });
  }, n2.search = function(e4) {
    var t3, r2, n3, o2 = e4.query;
    try {
      var i2 = this, a2 = "BING_JSONP_CB_" + Date.now();
      return Promise.resolve((t3 = i2.endpoint({
        query: o2,
        jsonp: a2
      }), r2 = a2, n3 = s("script", null, document.body), n3.setAttribute("type", "text/javascript"), new Promise(function(e5) {
        window[r2] = function(t4) {
          n3.remove(), delete window[r2], e5(t4);
        }, n3.setAttribute("src", t3);
      }))).then(function(e5) {
        return i2.parse({
          data: e5
        });
      });
    } catch (e5) {
      return Promise.reject(e5);
    }
  }, t2;
}(x);
var U = function(e3) {
  function t2() {
    for (var t3, r2 = arguments.length, n3 = new Array(r2), o2 = 0; o2 < r2; o2++) n3[o2] = arguments[o2];
    return (t3 = e3.call.apply(e3, [this].concat(n3)) || this).searchUrl = "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/find", t3;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = "string" == typeof t3 ? {
      text: t3
    } : t3;
    return r2.f = "json", this.getUrl(this.searchUrl, r2);
  }, n2.parse = function(e4) {
    return e4.data.locations.map(function(e5) {
      return {
        x: e5.feature.geometry.x,
        y: e5.feature.geometry.y,
        label: e5.name,
        bounds: [[e5.extent.ymin, e5.extent.xmin], [e5.extent.ymax, e5.extent.xmax]],
        raw: e5
      };
    });
  }, t2;
}(x);
var L = function(e3) {
  function t2(t3) {
    var r2;
    return void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).host = void 0, r2.host = t3.host || "http://localhost:4000", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query;
    return e4.type === h.REVERSE ? this.getUrl(this.host + "/v1/reverse", "string" == typeof t3 ? {} : t3) : this.getUrl(this.host + "/v1/autocomplete", "string" == typeof t3 ? {
      text: t3
    } : t3);
  }, n2.parse = function(e4) {
    return e4.data.features.map(function(e5) {
      var t3 = {
        x: e5.geometry.coordinates[0],
        y: e5.geometry.coordinates[1],
        label: e5.properties.label,
        bounds: null,
        raw: e5
      };
      return Array.isArray(e5.bbox) && 4 === e5.bbox.length && (t3.bounds = [[e5.bbox[1], e5.bbox[0]], [e5.bbox[3], e5.bbox[2]]]), t3;
    });
  }, t2;
}(x);
var S = function(e3) {
  function t2(t3) {
    return void 0 === t3 && (t3 = {}), t3.host = "https://api.geocode.earth", e3.call(this, t3) || this;
  }
  return r(t2, e3), t2;
}(L);
function C(e3) {
  return e3 && e3.__esModule && Object.prototype.hasOwnProperty.call(e3, "default") ? e3.default : e3;
}
var P;
var R = C(function e2(t2, r2) {
  if (t2 === r2) return true;
  if (t2 && r2 && "object" == typeof t2 && "object" == typeof r2) {
    if (t2.constructor !== r2.constructor) return false;
    var n2, o2, i2;
    if (Array.isArray(t2)) {
      if ((n2 = t2.length) != r2.length) return false;
      for (o2 = n2; 0 != o2--; ) if (!e2(t2[o2], r2[o2])) return false;
      return true;
    }
    if (t2.constructor === RegExp) return t2.source === r2.source && t2.flags === r2.flags;
    if (t2.valueOf !== Object.prototype.valueOf) return t2.valueOf() === r2.valueOf();
    if (t2.toString !== Object.prototype.toString) return t2.toString() === r2.toString();
    if ((n2 = (i2 = Object.keys(t2)).length) !== Object.keys(r2).length) return false;
    for (o2 = n2; 0 != o2--; ) if (!Object.prototype.hasOwnProperty.call(r2, i2[o2])) return false;
    for (o2 = n2; 0 != o2--; ) {
      var s2 = i2[o2];
      if (!e2(t2[s2], r2[s2])) return false;
    }
    return true;
  }
  return t2 != t2 && r2 != r2;
});
!function(e3) {
  e3[e3.INITIALIZED = 0] = "INITIALIZED", e3[e3.LOADING = 1] = "LOADING", e3[e3.SUCCESS = 2] = "SUCCESS", e3[e3.FAILURE = 3] = "FAILURE";
}(P || (P = {}));
var j = class _j {
  constructor({
    apiKey: e3,
    authReferrerPolicy: t2,
    channel: r2,
    client: n2,
    id: o2 = "__googleMapsScriptId",
    language: i2,
    libraries: s2 = [],
    mapIds: a2,
    nonce: l2,
    region: c2,
    retries: u2 = 3,
    url: h2 = "https://maps.googleapis.com/maps/api/js",
    version: p2
  }) {
    if (this.callbacks = [], this.done = false, this.loading = false, this.errors = [], this.apiKey = e3, this.authReferrerPolicy = t2, this.channel = r2, this.client = n2, this.id = o2 || "__googleMapsScriptId", this.language = i2, this.libraries = s2, this.mapIds = a2, this.nonce = l2, this.region = c2, this.retries = u2, this.url = h2, this.version = p2, _j.instance) {
      if (!R(this.options, _j.instance.options)) throw new Error(`Loader must not be called again with different options. ${JSON.stringify(this.options)} !== ${JSON.stringify(_j.instance.options)}`);
      return _j.instance;
    }
    _j.instance = this;
  }
  get options() {
    return {
      version: this.version,
      apiKey: this.apiKey,
      channel: this.channel,
      client: this.client,
      id: this.id,
      libraries: this.libraries,
      language: this.language,
      region: this.region,
      mapIds: this.mapIds,
      nonce: this.nonce,
      url: this.url,
      authReferrerPolicy: this.authReferrerPolicy
    };
  }
  get status() {
    return this.errors.length ? P.FAILURE : this.done ? P.SUCCESS : this.loading ? P.LOADING : P.INITIALIZED;
  }
  get failed() {
    return this.done && !this.loading && this.errors.length >= this.retries + 1;
  }
  createUrl() {
    let e3 = this.url;
    return e3 += "?callback=__googleMapsCallback&loading=async", this.apiKey && (e3 += `&key=${this.apiKey}`), this.channel && (e3 += `&channel=${this.channel}`), this.client && (e3 += `&client=${this.client}`), this.libraries.length > 0 && (e3 += `&libraries=${this.libraries.join(",")}`), this.language && (e3 += `&language=${this.language}`), this.region && (e3 += `&region=${this.region}`), this.version && (e3 += `&v=${this.version}`), this.mapIds && (e3 += `&map_ids=${this.mapIds.join(",")}`), this.authReferrerPolicy && (e3 += `&auth_referrer_policy=${this.authReferrerPolicy}`), e3;
  }
  deleteScript() {
    const e3 = document.getElementById(this.id);
    e3 && e3.remove();
  }
  load() {
    return this.loadPromise();
  }
  loadPromise() {
    return new Promise((e3, t2) => {
      this.loadCallback((r2) => {
        r2 ? t2(r2.error) : e3(window.google);
      });
    });
  }
  importLibrary(e3) {
    return this.execute(), google.maps.importLibrary(e3);
  }
  loadCallback(e3) {
    this.callbacks.push(e3), this.execute();
  }
  setScript() {
    var e3, t2;
    if (document.getElementById(this.id)) return void this.callback();
    const r2 = {
      key: this.apiKey,
      channel: this.channel,
      client: this.client,
      libraries: this.libraries.length && this.libraries,
      v: this.version,
      mapIds: this.mapIds,
      language: this.language,
      region: this.region,
      authReferrerPolicy: this.authReferrerPolicy
    };
    Object.keys(r2).forEach((e4) => !r2[e4] && delete r2[e4]), (null === (t2 = null === (e3 = null === window || void 0 === window ? void 0 : window.google) || void 0 === e3 ? void 0 : e3.maps) || void 0 === t2 ? void 0 : t2.importLibrary) || ((e4) => {
      let t3, r3, n3, o2 = "The Google Maps JavaScript API", i2 = "google", s2 = "importLibrary", a2 = "__ib__", l2 = document, c2 = window;
      c2 = c2[i2] || (c2[i2] = {});
      const u2 = c2.maps || (c2.maps = {}), h2 = /* @__PURE__ */ new Set(), p2 = new URLSearchParams(), d2 = () => t3 || (t3 = new Promise((s3, c3) => {
        return d3 = this, m2 = function* () {
          var d4;
          for (n3 in yield r3 = l2.createElement("script"), r3.id = this.id, p2.set("libraries", [...h2] + ""), e4) p2.set(n3.replace(/[A-Z]/g, (e5) => "_" + e5[0].toLowerCase()), e4[n3]);
          p2.set("callback", i2 + ".maps." + a2), r3.src = this.url + "?" + p2, u2[a2] = s3, r3.onerror = () => t3 = c3(Error(o2 + " could not load.")), r3.nonce = this.nonce || (null === (d4 = l2.querySelector("script[nonce]")) || void 0 === d4 ? void 0 : d4.nonce) || "", l2.head.append(r3);
        }, new ((f2 = void 0) || (f2 = Promise))(function(e5, t4) {
          function r4(e6) {
            try {
              o3(m2.next(e6));
            } catch (e7) {
              t4(e7);
            }
          }
          function n4(e6) {
            try {
              o3(m2.throw(e6));
            } catch (e7) {
              t4(e7);
            }
          }
          function o3(t5) {
            var o4;
            t5.done ? e5(t5.value) : (o4 = t5.value, o4 instanceof f2 ? o4 : new f2(function(e6) {
              e6(o4);
            })).then(r4, n4);
          }
          o3((m2 = m2.apply(d3, [])).next());
        });
        var d3, f2, m2;
      }));
      u2[s2] ? console.warn(o2 + " only loads once. Ignoring:", e4) : u2[s2] = (e5, ...t4) => h2.add(e5) && d2().then(() => u2[s2](e5, ...t4));
    })(r2);
    const n2 = this.libraries.map((e4) => this.importLibrary(e4));
    n2.length || n2.push(this.importLibrary("core")), Promise.all(n2).then(() => this.callback(), (e4) => {
      const t3 = new ErrorEvent("error", {
        error: e4
      });
      this.loadErrorCallback(t3);
    });
  }
  reset() {
    this.deleteScript(), this.done = false, this.loading = false, this.errors = [], this.onerrorEvent = null;
  }
  resetIfRetryingFailed() {
    this.failed && this.reset();
  }
  loadErrorCallback(e3) {
    if (this.errors.push(e3), this.errors.length <= this.retries) {
      const e4 = this.errors.length * Math.pow(2, this.errors.length);
      console.error(`Failed to load Google Maps script, retrying in ${e4} ms.`), setTimeout(() => {
        this.deleteScript(), this.setScript();
      }, e4);
    } else this.onerrorEvent = e3, this.callback();
  }
  callback() {
    this.done = true, this.loading = false, this.callbacks.forEach((e3) => {
      e3(this.onerrorEvent);
    }), this.callbacks = [];
  }
  execute() {
    if (this.resetIfRetryingFailed(), this.done) this.callback();
    else {
      if (window.google && window.google.maps && window.google.maps.version) return console.warn("Google Maps already loaded outside @googlemaps/js-api-loader.This may result in undesirable behavior as options and script parameters may not match."), void this.callback();
      this.loading || (this.loading = true, this.setScript());
    }
  }
};
var A = function(e3) {
  function t2(t3) {
    var r2;
    return (r2 = e3.call(this, t3) || this).loader = null, r2.geocoder = null, "undefined" != typeof window && (r2.loader = new j(t3).load().then(function(e4) {
      var t4 = new e4.maps.Geocoder();
      return r2.geocoder = t4, t4;
    })), r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    throw new Error("Method not implemented.");
  }, n2.parse = function(e4) {
    return e4.data.results.map(function(e5) {
      var t3 = e5.geometry.location.toJSON(), r2 = t3.lat, n3 = t3.lng, o2 = e5.geometry.viewport.toJSON();
      return {
        x: n3,
        y: r2,
        label: e5.formatted_address,
        bounds: [[o2.south, o2.west], [o2.north, o2.east]],
        raw: e5
      };
    });
  }, n2.search = function(e4) {
    try {
      var t3 = function(t4) {
        if (!t4) throw new Error("GoogleMaps GeoCoder is not loaded. Are you trying to run this server side?");
        return Promise.resolve(t4.geocode({
          address: e4.query
        }, function(e5) {
          return {
            results: e5
          };
        }).catch(function(e5) {
          return "ZERO_RESULTS" !== e5.code && console.error(e5.code + ": " + e5.message), {
            results: []
          };
        })).then(function(e5) {
          return r2.parse({
            data: e5
          });
        });
      }, r2 = this, n3 = r2.geocoder;
      return Promise.resolve(n3 ? t3(n3) : Promise.resolve(r2.loader).then(t3));
    } catch (e5) {
      return Promise.reject(e5);
    }
  }, t2;
}(x);
var I = function(e3) {
  function t2() {
    for (var t3, r2 = arguments.length, n3 = new Array(r2), o2 = 0; o2 < r2; o2++) n3[o2] = arguments[o2];
    return (t3 = e3.call.apply(e3, [this].concat(n3)) || this).searchUrl = "https://maps.googleapis.com/maps/api/geocode/json", t3;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query;
    return this.getUrl(this.searchUrl, "string" == typeof t3 ? {
      address: t3
    } : t3);
  }, n2.parse = function(e4) {
    return e4.data.results.map(function(e5) {
      return {
        x: e5.geometry.location.lng,
        y: e5.geometry.location.lat,
        label: e5.formatted_address,
        bounds: [[e5.geometry.viewport.southwest.lat, e5.geometry.viewport.southwest.lng], [e5.geometry.viewport.northeast.lat, e5.geometry.viewport.northeast.lng]],
        raw: e5
      };
    });
  }, t2;
}(x);
var N = function(e3) {
  function t2() {
    for (var t3, r2 = arguments.length, n3 = new Array(r2), o2 = 0; o2 < r2; o2++) n3[o2] = arguments[o2];
    return (t3 = e3.call.apply(e3, [this].concat(n3)) || this).searchUrl = "https://geocode.search.hereapi.com/v1/autosuggest", t3;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query;
    return this.getUrl(this.searchUrl, "string" == typeof t3 ? {
      q: t3
    } : t3);
  }, n2.parse = function(e4) {
    return e4.data.items.filter(function(e5) {
      return void 0 !== e5.position;
    }).map(function(e5) {
      return {
        x: e5.position.lng,
        y: e5.position.lat,
        label: e5.address.label,
        bounds: null,
        raw: e5
      };
    });
  }, t2;
}(x);
var F = function(e3) {
  function t2(t3) {
    var r2;
    void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).searchUrl = void 0, r2.reverseUrl = void 0;
    var n3 = "https://nominatim.openstreetmap.org";
    return r2.searchUrl = t3.searchUrl || n3 + "/search", r2.reverseUrl = t3.reverseUrl || n3 + "/reverse", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = e4.type, n3 = "string" == typeof t3 ? {
      q: t3
    } : t3;
    return n3.format = "json", this.getUrl(r2 === h.REVERSE ? this.reverseUrl : this.searchUrl, n3);
  }, n2.parse = function(e4) {
    return (Array.isArray(e4.data) ? e4.data : [e4.data]).map(function(e5) {
      return {
        x: Number(e5.lon),
        y: Number(e5.lat),
        label: e5.display_name,
        bounds: [[parseFloat(e5.boundingbox[0]), parseFloat(e5.boundingbox[2])], [parseFloat(e5.boundingbox[1]), parseFloat(e5.boundingbox[3])]],
        raw: e5
      };
    });
  }, t2;
}(x);
var O = function(e3) {
  function n2(r2) {
    return e3.call(this, t({}, r2, {
      searchUrl: "https://locationiq.org/v1/search.php",
      reverseUrl: "https://locationiq.org/v1/reverse.php"
    })) || this;
  }
  return r(n2, e3), n2.prototype.parse = function(t2) {
    return t2.data.error ? [] : e3.prototype.parse.call(this, t2);
  }, n2;
}(F);
var q = function(e3) {
  function t2() {
    for (var t3, r2 = arguments.length, n3 = new Array(r2), o2 = 0; o2 < r2; o2++) n3[o2] = arguments[o2];
    return (t3 = e3.call.apply(e3, [this].concat(n3)) || this).searchUrl = "https://api.opencagedata.com/geocode/v1/json", t3;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = "string" == typeof t3 ? {
      q: t3
    } : t3;
    return r2.format = "json", this.getUrl(this.searchUrl, r2);
  }, n2.parse = function(e4) {
    return e4.data.results.map(function(e5) {
      return {
        x: e5.geometry.lng,
        y: e5.geometry.lat,
        label: e5.formatted,
        bounds: [[e5.bounds.southwest.lat, e5.bounds.southwest.lng], [e5.bounds.northeast.lat, e5.bounds.northeast.lng]],
        raw: e5
      };
    });
  }, n2.search = function(t3) {
    try {
      return Promise.resolve(t3.query.length < 2 ? [] : e3.prototype.search.call(this, t3));
    } catch (e4) {
      return Promise.reject(e4);
    }
  }, t2;
}(x);
var M = function(e3) {
  function t2(t3) {
    var r2;
    void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).searchUrl = void 0, r2.reverseUrl = void 0;
    var n3 = "https://civildefense.fit.vutbr.cz";
    return r2.searchUrl = t3.searchUrl || n3 + "/search", r2.reverseUrl = t3.reverseUrl || n3 + "/reverse", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = e4.type, n3 = "string" == typeof t3 ? {
      q: t3
    } : t3;
    return n3.format = "json", this.getUrl(r2 === h.REVERSE ? this.reverseUrl : this.searchUrl, n3);
  }, n2.parse = function(e4) {
    return (Array.isArray(e4.data) ? e4.data : [e4.data]).map(function(e5) {
      return {
        x: Number(e5.lon),
        y: Number(e5.lat),
        label: e5.display_name,
        bounds: [[parseFloat(e5.boundingbox[0]), parseFloat(e5.boundingbox[2])], [parseFloat(e5.boundingbox[1]), parseFloat(e5.boundingbox[3])]],
        raw: e5
      };
    });
  }, t2;
}(x);
var _ = function(e3) {
  function t2(t3) {
    var r2;
    return void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).searchUrl = void 0, r2.searchUrl = t3.searchUrl || "https://a.tiles.mapbox.com/v4/geocode/mapbox.places/", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    return this.getUrl("" + this.searchUrl + e4.query + ".json");
  }, n2.parse = function(e4) {
    return (Array.isArray(e4.data.features) ? e4.data.features : []).map(function(e5) {
      var t3 = null;
      return e5.bbox && (t3 = [[parseFloat(e5.bbox[1]), parseFloat(e5.bbox[0])], [parseFloat(e5.bbox[3]), parseFloat(e5.bbox[2])]]), {
        x: Number(e5.center[0]),
        y: Number(e5.center[1]),
        label: e5.place_name ? e5.place_name : e5.text,
        bounds: t3,
        raw: e5
      };
    });
  }, t2;
}(x);
var D = function(e3) {
  function t2(t3) {
    var r2;
    void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).searchUrl = void 0, r2.reverseUrl = void 0;
    var n3 = "https://api-adresse.data.gouv.fr";
    return r2.searchUrl = t3.searchUrl || n3 + "/search", r2.reverseUrl = t3.reverseUrl || n3 + "/reverse", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query;
    return this.getUrl(e4.type === h.REVERSE ? this.reverseUrl : this.searchUrl, "string" == typeof t3 ? {
      q: t3
    } : t3);
  }, n2.parse = function(e4) {
    return e4.data.features.map(function(e5) {
      return {
        x: e5.geometry.coordinates[0],
        y: e5.geometry.coordinates[1],
        label: e5.properties.label,
        bounds: null,
        raw: e5
      };
    });
  }, t2;
}(x);
var B = function(e3) {
  function t2(t3) {
    var r2;
    void 0 === t3 && (t3 = {}), (r2 = e3.call(this, t3) || this).searchUrl = void 0, r2.reverseUrl = void 0;
    var n3 = "https://api.geoapify.com/v1/geocode";
    return r2.searchUrl = t3.searchUrl || n3 + "/search", r2.reverseUrl = t3.reverseUrl || n3 + "/reverse", r2;
  }
  r(t2, e3);
  var n2 = t2.prototype;
  return n2.endpoint = function(e4) {
    var t3 = e4.query, r2 = e4.type, n3 = "string" == typeof t3 ? {
      text: t3
    } : t3;
    return n3.format = "json", this.getUrl(r2 === h.REVERSE ? this.reverseUrl : this.searchUrl, n3);
  }, n2.parse = function(e4) {
    return (Array.isArray(e4.data.results) ? e4.data.results : [e4.data.results]).map(function(e5) {
      return {
        x: Number(e5.lon),
        y: Number(e5.lat),
        label: e5.formatted,
        bounds: [[parseFloat(e5.bbox.lat1), parseFloat(e5.bbox.lon1)], [parseFloat(e5.bbox.lat2), parseFloat(e5.bbox.lon2)]],
        raw: e5
      };
    });
  }, t2;
}(x);
export {
  k as BingProvider,
  M as CivilDefenseMapProvider,
  U as EsriProvider,
  D as GeoApiFrProvider,
  w as GeoSearchControl,
  B as GeoapifyProvider,
  S as GeocodeEarthProvider,
  A as GoogleProvider,
  N as HereProvider,
  x as JsonProvider,
  I as LegacyGoogleProvider,
  O as LocationIQProvider,
  _ as MapBoxProvider,
  q as OpenCageProvider,
  F as OpenStreetMapProvider,
  L as PeliasProvider,
  w as SearchControl,
  v as SearchElement
};
//# sourceMappingURL=leaflet-geosearch.js.map
