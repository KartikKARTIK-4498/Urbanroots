import "./chunk-KTESVR3Q.js";

// node_modules/geofire-common/dist/geofire-common/index.esm.js
var GEOHASH_PRECISION = 10;
var BASE32 = "0123456789bcdefghjkmnpqrstuvwxyz";
var EARTH_MERI_CIRCUMFERENCE = 40007860;
var METERS_PER_DEGREE_LATITUDE = 110574;
var BITS_PER_CHAR = 5;
var MAXIMUM_BITS_PRECISION = 22 * BITS_PER_CHAR;
var EARTH_EQ_RADIUS = 6378137;
var E2 = 0.00669447819799;
var EPSILON = 1e-12;
function log2(x) {
  return Math.log(x) / Math.log(2);
}
function validateKey(key) {
  var error;
  if (typeof key !== "string") {
    error = "key must be a string";
  } else if (key.length === 0) {
    error = "key cannot be the empty string";
  } else if (1 + GEOHASH_PRECISION + key.length > 755) {
    error = "key is too long to be stored in Firebase";
  } else if (/[\[\].#$\/\u0000-\u001F\u007F]/.test(key)) {
    error = "key cannot contain any of the following characters: . # $ ] [ /";
  }
  if (typeof error !== "undefined") {
    throw new Error("Invalid GeoFire key '" + key + "': " + error);
  }
}
function validateLocation(location) {
  var error;
  if (!Array.isArray(location)) {
    error = "location must be an array";
  } else if (location.length !== 2) {
    error = "expected array of length 2, got length " + location.length;
  } else {
    var latitude = location[0];
    var longitude = location[1];
    if (typeof latitude !== "number" || isNaN(latitude)) {
      error = "latitude must be a number";
    } else if (latitude < -90 || latitude > 90) {
      error = "latitude must be within the range [-90, 90]";
    } else if (typeof longitude !== "number" || isNaN(longitude)) {
      error = "longitude must be a number";
    } else if (longitude < -180 || longitude > 180) {
      error = "longitude must be within the range [-180, 180]";
    }
  }
  if (typeof error !== "undefined") {
    throw new Error("Invalid GeoFire location '" + location + "': " + error);
  }
}
function validateGeohash(geohash) {
  var error;
  if (typeof geohash !== "string") {
    error = "geohash must be a string";
  } else if (geohash.length === 0) {
    error = "geohash cannot be the empty string";
  } else {
    for (var _i = 0, geohash_1 = geohash; _i < geohash_1.length; _i++) {
      var letter = geohash_1[_i];
      if (BASE32.indexOf(letter) === -1) {
        error = "geohash cannot contain '" + letter + "'";
      }
    }
  }
  if (typeof error !== "undefined") {
    throw new Error("Invalid GeoFire geohash '" + geohash + "': " + error);
  }
}
function degreesToRadians(degrees) {
  if (typeof degrees !== "number" || isNaN(degrees)) {
    throw new Error("Error: degrees must be a number");
  }
  return degrees * Math.PI / 180;
}
function geohashForLocation(location, precision) {
  if (precision === void 0) {
    precision = GEOHASH_PRECISION;
  }
  validateLocation(location);
  if (typeof precision !== "undefined") {
    if (typeof precision !== "number" || isNaN(precision)) {
      throw new Error("precision must be a number");
    } else if (precision <= 0) {
      throw new Error("precision must be greater than 0");
    } else if (precision > 22) {
      throw new Error("precision cannot be greater than 22");
    } else if (Math.round(precision) !== precision) {
      throw new Error("precision must be an integer");
    }
  }
  var latitudeRange = {
    min: -90,
    max: 90
  };
  var longitudeRange = {
    min: -180,
    max: 180
  };
  var hash = "";
  var hashVal = 0;
  var bits = 0;
  var even = 1;
  while (hash.length < precision) {
    var val = even ? location[1] : location[0];
    var range = even ? longitudeRange : latitudeRange;
    var mid = (range.min + range.max) / 2;
    if (val > mid) {
      hashVal = (hashVal << 1) + 1;
      range.min = mid;
    } else {
      hashVal = (hashVal << 1) + 0;
      range.max = mid;
    }
    even = !even;
    if (bits < 4) {
      bits++;
    } else {
      bits = 0;
      hash += BASE32[hashVal];
      hashVal = 0;
    }
  }
  return hash;
}
function metersToLongitudeDegrees(distance, latitude) {
  var radians = degreesToRadians(latitude);
  var num = Math.cos(radians) * EARTH_EQ_RADIUS * Math.PI / 180;
  var denom = 1 / Math.sqrt(1 - E2 * Math.sin(radians) * Math.sin(radians));
  var deltaDeg = num * denom;
  if (deltaDeg < EPSILON) {
    return distance > 0 ? 360 : 0;
  } else {
    return Math.min(360, distance / deltaDeg);
  }
}
function longitudeBitsForResolution(resolution, latitude) {
  var degs = metersToLongitudeDegrees(resolution, latitude);
  return Math.abs(degs) > 1e-6 ? Math.max(1, log2(360 / degs)) : 1;
}
function latitudeBitsForResolution(resolution) {
  return Math.min(log2(EARTH_MERI_CIRCUMFERENCE / 2 / resolution), MAXIMUM_BITS_PRECISION);
}
function wrapLongitude(longitude) {
  if (longitude <= 180 && longitude >= -180) {
    return longitude;
  }
  var adjusted = longitude + 180;
  if (adjusted > 0) {
    return adjusted % 360 - 180;
  } else {
    return 180 - -adjusted % 360;
  }
}
function boundingBoxBits(coordinate, size) {
  var latDeltaDegrees = size / METERS_PER_DEGREE_LATITUDE;
  var latitudeNorth = Math.min(90, coordinate[0] + latDeltaDegrees);
  var latitudeSouth = Math.max(-90, coordinate[0] - latDeltaDegrees);
  var bitsLat = Math.floor(latitudeBitsForResolution(size)) * 2;
  var bitsLongNorth = Math.floor(longitudeBitsForResolution(size, latitudeNorth)) * 2 - 1;
  var bitsLongSouth = Math.floor(longitudeBitsForResolution(size, latitudeSouth)) * 2 - 1;
  return Math.min(bitsLat, bitsLongNorth, bitsLongSouth, MAXIMUM_BITS_PRECISION);
}
function boundingBoxCoordinates(center, radius) {
  var latDegrees = radius / METERS_PER_DEGREE_LATITUDE;
  var latitudeNorth = Math.min(90, center[0] + latDegrees);
  var latitudeSouth = Math.max(-90, center[0] - latDegrees);
  var longDegsNorth = metersToLongitudeDegrees(radius, latitudeNorth);
  var longDegsSouth = metersToLongitudeDegrees(radius, latitudeSouth);
  var longDegs = Math.max(longDegsNorth, longDegsSouth);
  return [[center[0], center[1]], [center[0], wrapLongitude(center[1] - longDegs)], [center[0], wrapLongitude(center[1] + longDegs)], [latitudeNorth, center[1]], [latitudeNorth, wrapLongitude(center[1] - longDegs)], [latitudeNorth, wrapLongitude(center[1] + longDegs)], [latitudeSouth, center[1]], [latitudeSouth, wrapLongitude(center[1] - longDegs)], [latitudeSouth, wrapLongitude(center[1] + longDegs)]];
}
function geohashQuery(geohash, bits) {
  validateGeohash(geohash);
  var precision = Math.ceil(bits / BITS_PER_CHAR);
  if (geohash.length < precision) {
    return [geohash, geohash + "~"];
  }
  geohash = geohash.substring(0, precision);
  var base = geohash.substring(0, geohash.length - 1);
  var lastValue = BASE32.indexOf(geohash.charAt(geohash.length - 1));
  var significantBits = bits - base.length * BITS_PER_CHAR;
  var unusedBits = BITS_PER_CHAR - significantBits;
  var startValue = lastValue >> unusedBits << unusedBits;
  var endValue = startValue + (1 << unusedBits);
  if (endValue > 31) {
    return [base + BASE32[startValue], base + "~"];
  } else {
    return [base + BASE32[startValue], base + BASE32[endValue]];
  }
}
function geohashQueryBounds(center, radius) {
  validateLocation(center);
  var queryBits = Math.max(1, boundingBoxBits(center, radius));
  var geohashPrecision = Math.ceil(queryBits / BITS_PER_CHAR);
  var coordinates = boundingBoxCoordinates(center, radius);
  var queries = coordinates.map(function(coordinate) {
    return geohashQuery(geohashForLocation(coordinate, geohashPrecision), queryBits);
  });
  return queries.filter(function(query, index) {
    return !queries.some(function(other, otherIndex) {
      return index > otherIndex && query[0] === other[0] && query[1] === other[1];
    });
  });
}
function distanceBetween(location1, location2) {
  validateLocation(location1);
  validateLocation(location2);
  var radius = 6371;
  var latDelta = degreesToRadians(location2[0] - location1[0]);
  var lonDelta = degreesToRadians(location2[1] - location1[1]);
  var a = Math.sin(latDelta / 2) * Math.sin(latDelta / 2) + Math.cos(degreesToRadians(location1[0])) * Math.cos(degreesToRadians(location2[0])) * Math.sin(lonDelta / 2) * Math.sin(lonDelta / 2);
  var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return radius * c;
}
export {
  BASE32,
  BITS_PER_CHAR,
  E2,
  EARTH_EQ_RADIUS,
  EARTH_MERI_CIRCUMFERENCE,
  EPSILON,
  GEOHASH_PRECISION,
  MAXIMUM_BITS_PRECISION,
  METERS_PER_DEGREE_LATITUDE,
  boundingBoxBits,
  boundingBoxCoordinates,
  degreesToRadians,
  distanceBetween,
  geohashForLocation,
  geohashQuery,
  geohashQueryBounds,
  latitudeBitsForResolution,
  longitudeBitsForResolution,
  metersToLongitudeDegrees,
  validateGeohash,
  validateKey,
  validateLocation,
  wrapLongitude
};
//# sourceMappingURL=geofire-common.js.map
